//#region src/actor/actor.js
var e = foundry.dice.terms.Die, t = foundry.applications.handlebars.renderTemplate, n = class extends Actor {
	prepareData() {
		super.prepareData(), this.system, this.flags, (this.type === "character" || this.type === "hireling" || this.type === "creature") && this._prepareCharacterData(this);
	}
	_prepareCharacterData(e) {
		e.system;
	}
	rollStatSelect(e) {
		let t = "";
		for (let n of e) t += `<option value='${n[0]}'>${game.i18n.localize(`Maus.${n[1].label}`)}</option>`;
		new Dialog({
			title: game.i18n.localize("Maus.RollSelectType"),
			content: `<h2>${game.i18n.localize("Maus.RollSelectStat")}</h2> <select style='margin-bottom:10px;'name='stat' id='stat'> ${t}</select> <br/>`,
			buttons: {
				roll: {
					icon: "<i class=\"fas fa-check\"></i>",
					label: game.i18n.localize("Maus.Roll"),
					callback: (e) => this.rollStat(this.system.stats[e.find("[id=\"stat\"]")[0].value])
				},
				cancel: {
					icon: "<i class=\"fas fa-times\"></i>",
					label: game.i18n.localize("Maus.Cancel"),
					callback: () => {}
				}
			},
			default: "roll",
			close: () => {}
		}).render(!0);
	}
	rollStat(e) {
		let t = e.label?.charAt(0).toUpperCase() + e.label?.toLowerCase().slice(1);
		!e.label && Number.isNaN(t) && (t = e.charAt(0)?.toUpperCase() + e.toLowerCase().slice(1)), new Dialog({
			title: game.i18n.localize("Maus.RollSelectType"),
			content: `<h2> ${game.i18n.localize("Maus.RollAdvantageDisadvantage")}</h2> <select style='margin-bottom:10px;'name='advantage' id='advantage'> <option value='none'>${game.i18n.localize("Maus.RollNone")}</option> <option value='advantage'>${game.i18n.localize("Maus.RollAdvantageDisadvantage")}</option></select> <br/>`,
			buttons: {
				roll: {
					icon: "<i class=\"fas fa-check\"></i>",
					label: game.i18n.localize("Maus.Roll"),
					callback: async (t) => {
						await this.rollAttribute(e, t.find("[id=\"advantage\"]")[0].value);
					}
				},
				cancel: {
					icon: "<i class=\"fas fa-times\"></i>",
					label: game.i18n.localize("Maus.Cancel"),
					callback: () => {}
				}
			},
			default: "roll",
			close: () => {}
		}).render(!0);
	}
	rollItem(e, t = { event: null }) {
		let n = foundry.utils.duplicate(this.getEmbeddedDocument("Item", e));
		n.type === "weapon" ? new Dialog({
			title: game.i18n.localize("Maus.RollSelectStat"),
			content: `<h2> ${game.i18n.localize("Maus.RollEnhanced")}/${game.i18n.localize("Maus.RollImpaired")} </h2> <select style='margin-bottom:10px;'name='enhanced' id='enhanced'>\
        <option value='normal'>${game.i18n.localize("Maus.RollNormal")}</option>\
        <option value='enhanced'>${game.i18n.localize("Maus.RollEnhanced")}</option>\
        <option value='impaired'>${game.i18n.localize("Maus.RollImpaired")}</option></select> <br/>`,
			buttons: {
				roll: {
					icon: "<i class=\"fas fa-check\"></i>",
					label: game.i18n.localize("Maus.Roll"),
					callback: async (e) => {
						await this.rollWeapon(n, e.find("[id=\"enhanced\"]")[0].value);
					}
				},
				cancel: {
					icon: "<i class=\"fas fa-times\"></i>",
					label: game.i18n.localize("Maus.Cancel"),
					callback: () => {}
				}
			},
			default: "roll",
			close: () => {}
		}).render(!0) : n.type === "spell" ? new Dialog({
			title: "Select Stat",
			content: `<h2> ${game.i18n.localize("Maus.RollPowerDesc")} </h2> <input style='margin-bottom:10px;' name='power' id='power' value='1'></input><br/>`,
			buttons: {
				roll: {
					icon: "<i class=\"fas fa-check\"></i>",
					label: game.i18n.localize("Maus.Roll"),
					callback: async (e) => {
						await this.rollSpell(n, e.find("[id=\"power\"]")[0].value);
					}
				},
				cancel: {
					icon: "<i class=\"fas fa-times\"></i>",
					label: game.i18n.localize("Maus.Cancel"),
					callback: () => {}
				}
			},
			default: "roll",
			close: () => {}
		}).render(!0) : this.chatDesc(n);
	}
	async rollWeapon(e = "", n = "") {
		let r = e.system.weapon.selected === 0 ? e.system.weapon.dmg1 : e.system.weapon.dmg2;
		n === "impaired" && (r = "d4"), n === "enhanced" && (r = "d12");
		let i = new Roll(r);
		await i.evaluate();
		let a = this.formatDice(i), o = "<div style='margin-top: 5px;'>";
		for (let t = 0; t < e.system.pips.max; t++) t < e.system.pips.value ? o += "<i class=\"fas fa-circle\">&nbsp;</i>" : o += "<i class=\"far fa-circle\">&nbsp;</i>";
		o += "</div>";
		let s = {
			actor: this,
			data: { diceTotal: {
				damageValue: i.total,
				damageRoll: i
			} },
			item: e,
			pip: o,
			rollTitle: game.i18n.localize("Maus.RollDamage"),
			rollText: i.total,
			damageDice: r,
			weaponState: game.i18n.localize(`Maus.Roll${n.charAt(0).toUpperCase()}${n.slice(1)}`),
			isWeapon: !0,
			diceData: a
		}, c = {
			user: game.user.id,
			speaker: {
				actor: this.id,
				token: this.token,
				alias: this.name
			}
		}, l = game.settings.get("core", "rollMode");
		["gmroll", "blindroll"].includes(l) && (c.whisper = ChatMessage.getWhisperRecipients("GM")), c.content = await t("systems/mausritter/templates/chat/statroll.html", s), game.dice3d ? await game.dice3d.showForRoll(i, game.user, !0, c.whisper, c.blind) : c.sound = CONFIG.sounds.dice, await ChatMessage.create(c);
	}
	async rollSpell(e = "", n = "") {
		let r = `${n}d6`, i = new Roll(r);
		await i.evaluate();
		let a = this.formatDice(i), o = "", s = 0, c = 0;
		for (let e = 0; e < Number.parseInt(n, 10); e++) e > 0 ? o += `, ${a.dice[e].result}` : o += `${a.dice[e].result}`, a.dice[e].result >= 4 && (s++, a.dice[e].result === 6 && c++);
		if (e.system.description ?? (e.system.description = ""), e.system.description = e.system.description.split(game.i18n.localize("Maus.RollDiceKeyword")).join(`<strong style='text-decoration:underline' class='red'>${n}</strong>`), e.system.description = e.system.description.split(game.i18n.localize("Maus.RollSumKeyword")).join(`<strong style='text-decoration:underline' class='red'>${i.total}</strong>`), e.system.description += `<h2>${game.i18n.localize("Maus.RollUsage")}: <strong>${s}</strong></h2>`, c) {
			let t = game.i18n.localize("Maus.RollMiscastDesc");
			t = t.replace("!miscast!", `${c}`), e.system.description += `<h2>${game.i18n.localize("Maus.RollMiscast")}: <strong>${c}</strong> </h2>${t}`;
		}
		let l = "<div style='margin-top: 5px;'>";
		for (let t = 0; t < e.system.pips.max; t++) t < e.system.pips.value ? l += "<i class=\"fas fa-circle\">&nbsp;</i>" : l += "<i class=\"far fa-circle\">&nbsp;</i>";
		l += "</div>";
		let u = {
			actor: this,
			data: {
				diceTotal: {
					damageValue: i.total,
					damageRoll: i
				},
				rollDiv: o
			},
			item: e,
			pip: l,
			isSpell: !0,
			isWeapon: !0,
			rollTitle: `${game.i18n.localize("Maus.RollSum")}|${game.i18n.localize("Maus.RollDice")}`,
			rollText: `${i.total}|${n}`,
			sum: i.total,
			dice: n,
			diceData: a
		}, d = {
			user: game.user.id,
			speaker: {
				actor: this.id,
				token: this.token,
				alias: this.name
			}
		}, f = game.settings.get("core", "rollMode");
		["gmroll", "blindroll"].includes(f) && (d.whisper = ChatMessage.getWhisperRecipients("GM")), d.content = await t("systems/mausritter/templates/chat/statroll.html", u), game.dice3d ? await game.dice3d.showForRoll(i, game.user, !0, d.whisper, d.blind) : d.sound = CONFIG.sounds.dice, await ChatMessage.create(d);
	}
	async rollAttribute(e, n, r = "", i = !1) {
		let a = e.label?.charAt(0).toUpperCase() + e.label?.toLowerCase().slice(1);
		!e.label && Number.isNaN(a) && (a = e.charAt(0)?.toUpperCase() + e.toLowerCase().slice(1));
		let o = "1d20", s = new Roll(o, {});
		await s.evaluate(), `${s.total}`.split("");
		let c = new Roll(o, {});
		await c.evaluate();
		let l = 0;
		r?.type === "weapon" && (l = new Roll(r.system.damage), await l.evaluate());
		let u = this.formatDice(s), d = 0;
		e.mod > 0 && (d = e.mod);
		let f = e.value + d + (r === "" ? 0 : r.system.bonus), p = "";
		p = i === !0 ? s.total >= f ? game.i18n.localize("Maus.RollSuccess") : game.i18n.localize("Maus.RollFailure") : s.total <= f ? game.i18n.localize("Maus.RollSuccess") : game.i18n.localize("Maus.RollFailure");
		let m = {
			actor: this,
			stat: { name: game.i18n.localize(`Maus.${a}`).toUpperCase() },
			data: {
				diceTotal: {
					value: s.total,
					advantageValue: c.total,
					damageValue: typeof l == "number" ? l : l.total,
					damageRoll: l
				},
				resultText: { value: p },
				isCreature: { value: this.type === "hireling" }
			},
			target: e.value,
			mod: d,
			item: r,
			targetValue: f,
			useSkill: r?.type === "skill",
			isWeapon: r?.type === "weapon",
			advantage: n === "advantage",
			diceData: u
		}, h = {
			user: game.user.id,
			speaker: {
				actor: this.id,
				token: this.token,
				alias: this.name
			}
		}, g = game.settings.get("core", "rollMode");
		["gmroll", "blindroll"].includes(g) && (h.whisper = ChatMessage.getWhisperRecipients("GM")), h.content = await t("systems/mausritter/templates/chat/statroll.html", m), game.dice3d ? await game.dice3d.showForRoll(s, game.user, !0, h.whisper, h.blind) : h.sound = CONFIG.sounds.dice, await ChatMessage.create(h);
	}
	formatDice(t) {
		let n = { dice: [] };
		if (t != null) {
			let r = (e, t, n, r) => {
				let i = null;
				[
					4,
					6,
					8,
					10,
					12,
					20
				].indexOf(n) > -1 && (i = `../icons/svg/d${n}-grey.svg`), e.dice.push({
					img: i,
					result: t,
					dice: !0,
					color: r
				});
			};
			for (let i = 0; i < t.terms.length; i++) if (t.terms[i] instanceof e) {
				let e = t.terms[i].results, a = t.terms[i].faces;
				for (let t of e) t.discarded ? r(n, t.result, a, "#777") : r(n, t.result, a, "white");
			} else if (typeof t.terms[i] == "string") {
				let e = Number.parseInt(t.terms[i], 10);
				Number.isNaN(e) ? n.dice.push({
					img: null,
					result: t.terms[i],
					dice: !1
				}) : n.dice.push({
					img: null,
					result: e,
					dice: !1,
					color: "white"
				});
			} else if (typeof t.terms[i] == "number") {
				let e = Number.parseInt(t.terms[i], 10);
				Number.isNaN(e) ? n.dice.push({
					img: null,
					result: t.terms[i],
					dice: !1
				}) : n.dice.push({
					img: null,
					result: e,
					dice: !1,
					color: "white"
				});
			}
		}
		return n;
	}
	chatDesc(e) {
		let n = e.name?.charAt(0).toUpperCase() + e.name?.toLowerCase().slice(1);
		!e.name && Number.isNaN(n) && (n = e.charAt(0)?.toUpperCase() + e.toLowerCase().slice(1));
		let r = "<div style='margin-top: 5px;'>";
		for (let t = 0; t < e.system.pips.max; t++) t < e.system.pips.value ? r += "<i class=\"fas fa-circle\">&nbsp;</i>" : r += "<i class=\"far fa-circle\">&nbsp;</i>";
		r += "</div>", e.system.description == null ? e.system.description = "" : e.system.description.length > 0 && (e.system.description += "<br/>"), e.type === "condition" && (e.system.description += `${e.system.desc}<br/><strong>Clear: </strong>${e.system.clear}`);
		let i = {
			actor: this,
			stat: { name: n.toUpperCase() },
			item: e,
			pip: r,
			onlyDesc: !0
		}, a = {
			user: game.user.id,
			speaker: {
				actor: this.id,
				token: this.token,
				alias: this.name
			}
		}, o = game.settings.get("core", "rollMode");
		["gmroll", "blindroll"].includes(o) && (a.whisper = ChatMessage.getWhisperRecipients("GM")), t("systems/mausritter/templates/chat/statroll.html", i).then((e) => {
			a.content = e, ChatMessage.create(a);
		});
	}
}, r = foundry.appv1.sheets.ActorSheet, i = class extends r {
	static get defaultOptions() {
		return foundry.utils.mergeObject(r.defaultOptions, {
			classes: [
				"mausritter",
				"sheet",
				"actor",
				"character"
			],
			template: "systems/mausritter/templates/actor/actor-sheet.html",
			width: 742,
			height: 800,
			tabs: [{
				navSelector: ".sheet-tabs",
				contentSelector: ".sheet-body",
				initial: "character"
			}]
		});
	}
	getData() {
		let e = super.getData();
		return e.dtypes = [
			"String",
			"Number",
			"Boolean"
		], e.data.system, this.actor.type === "character" && this._prepareCharacterItems(e), e.data.system.settings ?? (e.data.system.settings = {}), e.data;
	}
	_prepareCharacterItems(e) {
		let t = e.actor, n = [];
		for (let t of e.items) {
			let e = t.system;
			t.img = t.img || DEFAULT_TOKEN, e.pips ??= {
				value: 0,
				max: 0,
				html: ""
			};
			let r = "";
			for (let t = 0; t < e.pips.max; t++) t < e.pips.value ? r += "<i class=\"fas fa-circle\"></i>" : r += "<i class=\"far fa-circle\"></i>";
			e.pips.html = r, t.type === "item" ? (e.isWeapon = !1, e.isCondition = !1) : t.type === "weapon" && (e.isWeapon = !0, e.isCondition = !1, e.weapon.dmg2 === "" ? e.weapon.canSwap = !1 : e.weapon.canSwap = !0), e.size === void 0 && (e.size = {
				width: 1,
				height: 1,
				x: "9em",
				y: "9em"
			}), e.sheet.rotation === void 0 && (e.sheet.rotation = 0), e.size.aspect = e.sheet.rotation === -90 ? e.size.width > e.size.height ? e.size.width / e.size.height : e.size.height / e.size.width : 1, e.sheet.curHeight = e.sheet.rotation === -90 ? e.size.width : e.size.height, e.sheet.curWidth = e.sheet.rotation === -90 ? e.size.height : e.size.width, e.size.x = `${e.sheet.curWidth * 8 + e.sheet.curWidth}em`, e.size.y = `${e.sheet.curHeight * 8 + e.sheet.curHeight}em`;
			let i = Math.round(e.sheet.currentX / 5) * 5, a = Math.round(e.sheet.currentY / 5) * 5;
			e.sheet.currentX = i, e.sheet.currentY = a, e.sheet.zIndex = i + a + 1e3, t.type !== "storage" && (e.store = null), n.push(t);
		}
		t.gear = n;
	}
	activateListeners(e) {
		if (super.activateListeners(e), this.options.editable && (e.find(".item-equip").click((e) => {
			let t = $(e.currentTarget).parents(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.equipped = !n.system.equipped, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".item-create").click((e) => {
			let t = [
				"item",
				"weapon",
				"spell",
				"armor",
				"condition",
				"storage"
			], n = "";
			for (let e of t) n += `<option value='${e}'>${e}</option>`;
			new Dialog({
				title: "Select Stat",
				content: `<h2> Item Type </h2> <select style='margin-bottom:10px;'name='type' id='type'> ${n}</select> <br/>`,
				buttons: {
					roll: {
						icon: "<i class=\"fas fa-check\"></i>",
						label: "Create",
						callback: async (t) => {
							this._onItemCreate(e, t.find("[id=\"type\"]")[0].value);
						}
					},
					cancel: {
						icon: "<i class=\"fas fa-times\"></i>",
						label: "Cancel",
						callback: () => {}
					}
				},
				default: "roll",
				close: () => {}
			}).render(!0);
		}), e.find(".item-edit").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.getEmbeddedDocument("Item", t.data("itemId")).sheet.render(!0);
		}), e.find(".item-delete").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.deleteEmbeddedDocuments("Item", [t.data("itemId")]), t.slideUp(200, () => this.render(!1));
		}), e.find(".item-rotate").click((e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.sheet.rotation === -90 ? n.system.sheet.rotation = 0 : n.system.sheet.rotation = -90, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".stat-roll").click((e) => {
			let t = $(e.currentTarget).data("key"), n = this.actor.system.stats[t];
			this.actor.rollStat(n);
		}), e.find(".item-roll").click((e) => {
			let t = e.currentTarget.closest(".item");
			this.actor.rollItem(t.dataset.itemId, { event: e });
		}), e.on("change", ".item-input", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = $(e.currentTarget);
			n[r[0].name] = r[0].value, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".pip-button", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.pips.value;
			event.button === 0 ? r < n.system.pips.max && (n.system.pips.value = Number(r) + 1) : event.button === 2 && r > 0 && (n.system.pips.value = Number(r) - 1), this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".damage-swap", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.weapon.dmg1, i = n.system.weapon.dmg2;
			n.system.weapon.dmg1 = i, n.system.weapon.dmg2 = r, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), this.actor.isOwner)) {
			let t = (e) => this._onDragItemStart(e), n = (e) => this._onDragOver(e);
			e.find("li.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			}), e.find("div.dropitem").each((e, r) => {
				r.classList.contains("inventory-header") || (r.setAttribute("draggable", !0), r.addEventListener("dragstart", t, !1), r.addEventListener("dragend", n, !1));
			});
		}
	}
	_onItemCreate(e, t) {
		e.preventDefault();
		let n = e.currentTarget, r = foundry.utils.duplicate(n.dataset), i = {
			name: `New ${t.capitalize()}`,
			type: t,
			data: r
		};
		return i.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [i]);
	}
	_onSkillCreate(e) {
		e.preventDefault();
		let t = e.currentTarget, n = {
			name: "New Skill",
			type: t.dataset.type,
			data: foundry.utils.duplicate(t.dataset)
		};
		return n.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [n]);
	}
	_onRoll(e) {
		e.preventDefault();
		let t = e.currentTarget.dataset;
		if (t.roll) {
			let e = new Roll(t.roll, this.actor.system), n = t.label ? `Rolling ${t.label} to score under ${t.target}` : "";
			e.roll().toMessage({
				speaker: ChatMessage.getSpeaker({ actor: this.actor }),
				flavor: n
			});
		}
	}
	async _updateObject(e, t) {
		let n = this.object, r = foundry.utils.expandObject(t);
		await n.update(r, { diff: !1 });
	}
	_onDragItemStart(e) {
		let t = e.currentTarget.getAttribute("data-item-id");
		if (!t) return;
		let n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t)), r = $(e.currentTarget), i = r.outerWidth(), a = r.outerHeight(), o = e.pageX - r.offset().left - i / 2, s = e.pageY - r.offset().top - a / 2;
		$(`#${t}`), n.system.stored = "";
		let c = n;
		e.dataTransfer.setData("text/plain", JSON.stringify({
			type: "Item",
			sheetTab: this.actor.flags._sheetTab,
			actorId: this.actor.id,
			itemId: t,
			fromToken: this.actor.isToken,
			offset: {
				x: o,
				y: s
			},
			data: c,
			root: e.currentTarget.getAttribute("root")
		}));
	}
	_onDragOver(e) {}
	async _onDropItem(e, t) {
		if (!this.actor.isOwner) return !1;
		let n = await Item.fromDropData(t), r = foundry.utils.duplicate(n), i = this.actor, a = $(e.target);
		a.attr("id") !== "drag-area" && (a = a.parents("#drag-area"));
		let o = 0, s = 0;
		if (a.length) {
			let t = a.outerWidth(), n = a.outerHeight();
			o = e.pageX - a.offset().left - t / 2, s = e.pageY - a.offset().top - n / 2;
		}
		if ((t.actorId === i.id || i.isToken && t.tokenId === i.token.id) && !e.ctrlKey) {
			let e = foundry.utils.duplicate(i.getEmbeddedDocument("Item", t.itemId));
			e.system.sheet = {
				currentX: o - t.offset.x,
				currentY: s - t.offset.y,
				initialX: o - t.offset.x,
				initialY: s - t.offset.y,
				xOffset: o - t.offset.x,
				yOffset: s - t.offset.y
			}, i.updateEmbeddedDocuments("Item", [e]);
			return;
		}
		return t.actorId && !e.ctrlKey && !t.fromToken && !this.actor.isToken && game.actors.get(t.actorId).deleteEmbeddedDocuments("Item", [t.itemId]), t.offset ||= {
			x: 0,
			y: 0
		}, r.system.sheet = {
			currentX: o - t.offset.x,
			currentY: s - t.offset.y,
			initialX: o - t.offset.x,
			initialY: s - t.offset.y,
			xOffset: o - t.offset.x,
			yOffset: s - t.offset.y
		}, this._onDropItemCreate(r);
	}
}, a = foundry.applications.handlebars.renderTemplate;
async function o(e, t) {
	let n = await a("systems/mausritter/templates/dialogs/additional-item-choice.html", { items: e });
	new Dialog({
		title: game.i18n.localize("Maus.CC.AdditionalStartingItem"),
		content: n,
		buttons: { ok: {
			icon: "<i class=\"fas fa-check\"></i>",
			label: game.i18n.localize("Maus.OK"),
			callback: (e) => {
				t(e[0].querySelector("select").selectedIndex);
			}
		} },
		default: "ok",
		close: () => {}
	}).render(!0);
}
//#endregion
//#region src/actor/create-character/additional-items-info-dialog.js
var s = foundry.applications.handlebars.renderTemplate;
async function c(e) {
	let t = await s("systems/mausritter/templates/dialogs/additional-item-info.html", { items: e });
	new Dialog({
		title: game.i18n.localize("Maus.CC.AdditionalStartingItem"),
		content: t,
		buttons: { ok: {
			icon: "<i class=\"fas fa-check\"></i>",
			label: game.i18n.localize("Maus.OK"),
			callback: (e) => {}
		} },
		default: "ok",
		close: () => {}
	}).render(!0);
}
//#endregion
//#region src/actor/create-character/create-character-dialog.js
var l = foundry.applications.handlebars.renderTemplate;
async function u(e) {
	let t = await l("systems/mausritter/templates/dialogs/create-character.html");
	new Dialog({
		title: game.i18n.localize("Maus.CC.WhatToCreate"),
		content: t,
		buttons: {
			roll: {
				icon: "<i class=\"fas fa-check\"></i>",
				label: game.i18n.localize("Maus.OK"),
				callback: (t) => {
					let n = t[0].querySelector("fieldset"), r = new foundry.applications.ux.FormDataExtended(n).object;
					e(r);
				}
			},
			cancel: {
				icon: "<i class=\"fas fa-times\"></i>",
				label: game.i18n.localize("Maus.Cancel"),
				callback: () => {}
			}
		},
		default: "roll",
		close: () => {}
	}).render(!0);
}
//#endregion
//#region src/actor/create-character/data.js
var d = {
	TORCHES: "Compendium.mausritter.gear.IhV9bZ3WX8sQnJAp",
	RATIONS: "Compendium.mausritter.gear.EuWZ26fjA7E0Gka0"
}, f = [
	{
		name: "Test subject",
		items: ["Compendium.mausritter.spells.Zk8WtKad1nbfOrCB", "Compendium.mausritter.armor.kcKH7sBam6En635G"],
		hp: 1,
		pips: 1
	},
	{
		name: "Kitchen forager",
		items: ["Compendium.mausritter.armor.MbCIEp6TzoK08akp", "Compendium.mausritter.gear.OZrpQkk9qrfvE79X"],
		hp: 1,
		pips: 2
	},
	{
		name: "Cage dweller",
		items: ["Compendium.mausritter.spells.u3fkvN7VxSVtEqSb", "Compendium.mausritter.gear.3b4wBjFkoWHTZ4D1"],
		hp: 1,
		pips: 3
	},
	{
		name: "Hedge witch",
		items: ["Compendium.mausritter.spells.CVKTeU3Sm6NRvDvj", "Compendium.mausritter.gear.h3vmVonEywSKtdjg"],
		hp: 1,
		pips: 4
	},
	{
		name: "Leatherworker",
		items: ["Compendium.mausritter.armor.MbCIEp6TzoK08akp", "Compendium.mausritter.gear.QXn9R6uDfBWTnQsT"],
		hp: 1,
		pips: 5
	},
	{
		name: "Street tough",
		items: ["Compendium.mausritter.weapons.w3BvIQul7s6pwkG8", "Compendium.mausritter.gear.yAW0nmonxXHg34iB"],
		hp: 1,
		pips: 6
	},
	{
		name: "Mendicant priest",
		items: ["Compendium.mausritter.spells.0bpvALvoKL2UbQU1", "Compendium.mausritter.gear.is0vgpj8gTf7A8Dh"],
		hp: 2,
		pips: 1
	},
	{
		name: "Beetleherd",
		items: ["Compendium.mausritter.gear.WbznGS06x1gFfJ0X", "Compendium.mausritter.gear.vOqvTbPWoqUbB1yQ"],
		hp: 2,
		pips: 2
	},
	{
		name: "Ale brewer",
		items: ["Compendium.mausritter.gear.t4KWOCDfm6L1AIFj", "Compendium.mausritter.gear.Q8VPlUXtYVdzRUbS"],
		hp: 2,
		pips: 3
	},
	{
		name: "Fishermouse",
		items: ["Compendium.mausritter.gear.0yCyJ6ADcFo6h08F", "Compendium.mausritter.weapons.kZVwXUFnlj4xi7zi"],
		hp: 2,
		pips: 4
	},
	{
		name: "Blacksmith",
		items: ["Compendium.mausritter.weapons.LIkXPQid5FNuX393", "Compendium.mausritter.gear.EW1wFKynBHddyyGq"],
		hp: 2,
		pips: 5
	},
	{
		name: "Wireworker",
		items: ["Compendium.mausritter.gear.TJEiqBJXGRuiOHEQ", "Compendium.mausritter.gear.4earZoyzJPwEnauz"],
		hp: 2,
		pips: 6
	},
	{
		name: "Woodcutter",
		items: ["Compendium.mausritter.weapons.2gK7hXzu3TDGllTK", "Compendium.mausritter.gear.zd7a3t2PWGbTuMyt"],
		hp: 3,
		pips: 1
	},
	{
		name: "Bat cultist",
		items: ["Compendium.mausritter.spells.PDHmM25EL2ywt157", "Compendium.mausritter.gear.UYBlJt4TrBfa6cCV"],
		hp: 3,
		pips: 2
	},
	{
		name: "Tin miner",
		items: ["Compendium.mausritter.weapons.HqrIfbl7JpRpC0tQ", "Compendium.mausritter.gear.BtSLesZiZQOt9yhj"],
		hp: 3,
		pips: 3
	},
	{
		name: "Trash collector",
		items: ["Compendium.mausritter.weapons.6tTCXWnqP2CK8IDe", "Compendium.mausritter.gear.A8tlvt6vgRHmIN91"],
		hp: 3,
		pips: 4
	},
	{
		name: "Wall rover",
		items: ["Compendium.mausritter.gear.zo3tuzkhjPuYkAOG", "Compendium.mausritter.gear.e4SXeMrmG7TbLyRc"],
		hp: 3,
		pips: 5
	},
	{
		name: "Merchant",
		items: ["Compendium.mausritter.gear.nuK5O2X68yGQQ3k3", "Compendium.mausritter.gear.k4VMEXr5yyhlSF2c"],
		hp: 3,
		pips: 6
	},
	{
		name: "Raft crew",
		items: ["Compendium.mausritter.weapons.LIkXPQid5FNuX393", "Compendium.mausritter.gear.KppUOvvn8XrFP5yG"],
		hp: 4,
		pips: 1
	},
	{
		name: "Worm wrangler",
		items: ["Compendium.mausritter.gear.vOqvTbPWoqUbB1yQ", "Compendium.mausritter.gear.wDXdllAA6LjjCT6e"],
		hp: 4,
		pips: 2
	},
	{
		name: "Sparrow rider",
		items: ["Compendium.mausritter.gear.zo3tuzkhjPuYkAOG", "Compendium.mausritter.gear.KN1j3bP1rAYXwh1R"],
		hp: 4,
		pips: 3
	},
	{
		name: "Sewer guide",
		items: ["Compendium.mausritter.gear.EW1wFKynBHddyyGq", "Compendium.mausritter.gear.e4SXeMrmG7TbLyRc"],
		hp: 4,
		pips: 4
	},
	{
		name: "Prison guard",
		items: ["Compendium.mausritter.gear.QgYJojJerwXayQQV", "Compendium.mausritter.weapons.Ttuqe7BGihXRLziq"],
		hp: 4,
		pips: 5
	},
	{
		name: "Fungus farmer",
		items: ["Compendium.mausritter.gear.TGNSgaCQsssts5os", "Compendium.mausritter.gear.ZsmzHWLCNH9M2L15"],
		hp: 4,
		pips: 6
	},
	{
		name: "Dam builder",
		items: ["Compendium.mausritter.gear.Ln1kjNNNetZBPJOd", "Compendium.mausritter.gear.KppUOvvn8XrFP5yG"],
		hp: 5,
		pips: 1
	},
	{
		name: "Cartographer",
		items: ["Compendium.mausritter.gear.8EMr2YGvQjhg3lej", "Compendium.mausritter.gear.3VafgHWZBnAFj8M3"],
		hp: 5,
		pips: 2
	},
	{
		name: "Trap thief",
		items: ["Compendium.mausritter.gear.EmOPMHKtWMua1zhF", "Compendium.mausritter.gear.0kVNBhOCRAWetQGb"],
		hp: 5,
		pips: 3
	},
	{
		name: "Vagabond",
		items: ["Compendium.mausritter.gear.vjwIDZpIeczbKbW3", "Compendium.mausritter.gear.U8zT0oNputtkmoKZ"],
		hp: 5,
		pips: 4
	},
	{
		name: "Grain farmer",
		items: ["Compendium.mausritter.weapons.Ttuqe7BGihXRLziq", "Compendium.mausritter.gear.2ibdQuqqcDrkdvTs"],
		hp: 5,
		pips: 5
	},
	{
		name: "Message runner",
		items: ["Compendium.mausritter.gear.8GMxZ1TCbhWQmwsv", "Compendium.mausritter.gear.PUc63ut2mgqUyGKs"],
		hp: 5,
		pips: 6
	},
	{
		name: "Troubadour",
		items: ["Compendium.mausritter.gear.k9kmk6zA3u9IbHqJ", "Compendium.mausritter.gear.H72u8auTR4p0A1cU"],
		hp: 6,
		pips: 1
	},
	{
		name: "Gambler",
		items: ["Compendium.mausritter.gear.V4ChlJOFAJg1TEtu", "Compendium.mausritter.gear.A8tlvt6vgRHmIN91"],
		hp: 6,
		pips: 2
	},
	{
		name: "Sap tapper",
		items: ["Compendium.mausritter.gear.Qx4VmVHXNmyacUkL", "Compendium.mausritter.gear.KppUOvvn8XrFP5yG"],
		hp: 6,
		pips: 3
	},
	{
		name: "Bee keeper",
		items: ["Compendium.mausritter.gear.vQIpvCoaRe23aq4g", "Compendium.mausritter.gear.0yCyJ6ADcFo6h08F"],
		hp: 6,
		pips: 4
	},
	{
		name: "Librarian",
		items: ["Compendium.mausritter.gear.jlvULohSiRf5ySqe", "Compendium.mausritter.gear.8EMr2YGvQjhg3lej"],
		hp: 6,
		pips: 5
	},
	{
		name: "Pauper noblemouse",
		items: ["Compendium.mausritter.gear.tBrL4wxGqs7pmLVi", "Compendium.mausritter.gear.l1GnC3gatjidKix9"],
		hp: 6,
		pips: 6
	}
], p = {
	axe: ["Compendium.mausritter.weapons.2gK7hXzu3TDGllTK"],
	bow: ["Compendium.mausritter.weapons.3UYDZQVca8rmErbU", "Compendium.mausritter.gear.eEh9d4ozBfoJJt7D"],
	cleaver: ["Compendium.mausritter.weapons.4fi0j9IibcIrZluK"],
	dagger: ["Compendium.mausritter.weapons.w3BvIQul7s6pwkG8"],
	hammer: ["Compendium.mausritter.weapons.LIkXPQid5FNuX393"],
	hookarm: ["Compendium.mausritter.weapons.6tTCXWnqP2CK8IDe"],
	mace: ["Compendium.mausritter.weapons.tpoh5HciZgfppCAt"],
	needle: ["Compendium.mausritter.weapons.kZVwXUFnlj4xi7zi"],
	pick: ["Compendium.mausritter.weapons.HqrIfbl7JpRpC0tQ"],
	sling: ["Compendium.mausritter.weapons.O7ZKkdJ5kmAzCOHr", "Compendium.mausritter.gear.cp458bYOtIwPZp4Q"],
	spear: ["Compendium.mausritter.weapons.Ttuqe7BGihXRLziq"],
	sword: ["Compendium.mausritter.weapons.R0VejRjAELxknNbN"],
	warhammer: ["Compendium.mausritter.weapons.uTBQtiPtEvUpntJH"]
}, m = -150, h = -20, g = {
	MAIN_PAW: {
		currentX: -270,
		currentY: m
	},
	OFF_PAW: {
		currentX: -270,
		currentY: h
	},
	UPPER_BODY: {
		currentX: -140,
		currentY: m
	},
	LOWER_BODY: {
		currentX: -140,
		currentY: h
	},
	SLOT_1: {
		currentX: 10,
		currentY: m
	},
	SLOT_2: {
		currentX: 140,
		currentY: m
	},
	SLOT_3: {
		currentX: 270,
		currentY: m
	},
	SLOT_4: {
		currentX: 10,
		currentY: h
	},
	SLOT_5: {
		currentX: 140,
		currentY: h
	},
	SLOT_6: {
		currentX: 270,
		currentY: h
	}
};
//#endregion
//#region src/actor/create-character/foundry-client.js
async function _(e) {
	return await Item.fromDropData({
		type: "Item",
		uuid: e
	});
}
async function v(e, t, n) {
	let r = await _(e), i = foundry.utils.duplicate(r);
	n && (i.system.sheet = n), await t.sheet._onDropItemCreate(i);
}
async function y() {
	let e = new Roll("3d6kh2");
	return await e.evaluate(), e.total;
}
async function b(e) {
	let t = await (await game.packs.filter((e) => e.documentName === "RollTable")).filter((e) => e.metadata.label === CONFIG.MAUSRITTER.tables.tables);
	if (t.length === 0) {
		ui.notifications.warn(`Table ${e} not found.`, {});
		return;
	}
	let n = await (await t[0].getDocuments()).filter((t) => t.name === e)[0];
	if (!n) {
		ui.notifications.warn(`Table ${e} not found.`, {});
		return;
	}
	let r = (await n.roll()).results[0];
	return r ? r.name ? r.name : r.description ? r.description.replace(/<[^>]+>/g, "").trim() : "" : "";
}
//#endregion
//#region src/actor/create-character/weapon-choice.js
var x = foundry.applications.handlebars.renderTemplate;
async function S(e) {
	let t = await x("systems/mausritter/templates/dialogs/weapon-choice.html");
	new Dialog({
		title: game.i18n.localize("Maus.CC.WhatWeapon"),
		content: t,
		buttons: {
			ok: {
				icon: "<i class=\"fas fa-check\"></i>",
				label: game.i18n.localize("Maus.OK"),
				callback: (t) => {
					e(t[0].querySelector("select").value);
				}
			},
			cancel: {
				icon: "<i class=\"fas fa-times\"></i>",
				label: game.i18n.localize("Maus.Cancel"),
				callback: () => {}
			}
		},
		default: "ok",
		close: () => {}
	}).render(!0);
}
//#endregion
//#region src/actor/create-character/create-character.js
async function C() {
	await u((e) => {
		e.items ? S((t) => {
			let n = p[t];
			w(e, n);
		}) : w(e);
	});
}
async function w(e, t) {
	let n = e.background ? O() : void 0, r = await D(n, e.stats, e.details), i = await Actor.create(r);
	if (e.background && e.items && await A(i, n), e.items && await k(i), t !== void 0) {
		let e = [g.MAIN_PAW, g.UPPER_BODY];
		for (let [n, r] of t.entries()) await v(r, i, e[n]);
	}
	await i.sheet.render(!0);
	let a = j(i.system.stats);
	if (a <= 7 && e.items && e.background) E(T(n)).then(async (e) => {
		let t = [g.SLOT_2, g.SLOT_5];
		for (let [n, r] of e.entries()) await v(r.uuid, i, t[n]);
		await c(e);
	});
	else if (a <= 9 && e.items && e.background) {
		let e = T(n), t = e.items;
		E(e).then(async (e) => {
			await o(e, async (e) => {
				await v(t[e], i, g.SLOT_2);
			});
		});
	}
}
function T(e) {
	let t = O();
	return t.name === e.name ? T(e) : t;
}
async function E(e) {
	return await Promise.all(e.items.map(async (e) => await _(e)));
}
async function D(e, t, n) {
	let r = t ? await y() : 0, i = t ? await y() : 0, a = t ? await y() : 0, o = e ? game.i18n.localize(`Maus.Background.${e.name}`) : "", s = e ? e.pips : 0, c = e ? e.hp : 0, l = n ? await b(CONFIG.MAUSRITTER.tables.birthsign) : "", u = n ? await b(CONFIG.MAUSRITTER.tables.physicalDetail) : "", d = n ? `${await b(CONFIG.MAUSRITTER.tables.coatPattern)} ${await b(CONFIG.MAUSRITTER.tables.coatColor)}` : "";
	return {
		name: await M(),
		type: "character",
		system: {
			stats: {
				dexterity: {
					max: r,
					value: r
				},
				strength: {
					max: i,
					value: i
				},
				will: {
					max: a,
					value: a
				}
			},
			health: {
				max: c,
				value: c
			},
			pips: { value: s },
			description: {
				background: o,
				birthsign: l,
				coat: d,
				look: u
			}
		}
	};
}
function O() {
	return f[Math.floor(Math.random() * f.length)];
}
async function k(e) {
	await v(d.TORCHES, e, g.SLOT_3), await v(d.RATIONS, e, g.SLOT_6);
}
async function A(e, t) {
	let n = [g.SLOT_1, g.SLOT_4];
	for (let [r, i] of t.items.entries()) await v(i, e, n[r]);
}
function j(e) {
	return Math.max(e.dexterity.max, e.will.max, e.strength.max);
}
async function M() {
	return `${await b(CONFIG.MAUSRITTER.tables.firstName)} ${await b(CONFIG.MAUSRITTER.tables.lastName)}`;
}
//#endregion
//#region src/actor/creature-sheet.js
var N = foundry.appv1.sheets.ActorSheet, P = class extends N {
	static get defaultOptions() {
		return foundry.utils.mergeObject(N.defaultOptions, {
			classes: [
				"mausritter",
				"sheet",
				"actor",
				"creature"
			],
			template: "systems/mausritter/templates/actor/creature-sheet.html",
			width: 680,
			height: 620,
			tabs: [{
				navSelector: ".sheet-tabs",
				contentSelector: ".sheet-body",
				initial: "character"
			}]
		});
	}
	getData() {
		let e = super.getData();
		return e.dtypes = [
			"String",
			"Number",
			"Boolean"
		], e.data.system, this.actor.type === "creature" && this._prepareCharacterItems(e), e.data.system.settings ?? (e.data.system.settings = {}), e.data;
	}
	_prepareCharacterItems(e) {
		let t = e.actor, n = [];
		for (let t of e.items) {
			let e = t.system;
			t.img = t.img || DEFAULT_TOKEN, e.pips ??= {
				value: 0,
				max: 0,
				html: ""
			};
			let r = "";
			for (let t = 0; t < e.pips.max; t++) t < e.pips.value ? r += "<i class=\"fas fa-circle\"></i>" : r += "<i class=\"far fa-circle\"></i>";
			e.pips.html = r, t.type === "item" ? (e.isWeapon = !1, e.isCondition = !1) : t.type === "weapon" && (e.isWeapon = !0, e.isCondition = !1, e.weapon.dmg2 === "" ? e.weapon.canSwap = !1 : e.weapon.canSwap = !0), e.size === void 0 && (e.size = {
				width: 1,
				height: 1,
				x: "9em",
				y: "9em"
			}), e.sheet.rotation === void 0 && (e.sheet.rotation = 0), e.size.aspect = e.sheet.rotation === -90 ? e.size.width > e.size.height ? e.size.width / e.size.height : e.size.height / e.size.width : 1, e.sheet.curHeight = e.sheet.rotation === -90 ? e.size.width : e.size.height, e.sheet.curWidth = e.sheet.rotation === -90 ? e.size.height : e.size.width, e.size.x = `${e.sheet.curWidth * 8 + e.sheet.curWidth}em`, e.size.y = `${e.sheet.curHeight * 8 + e.sheet.curHeight}em`;
			let i = Math.round(e.sheet.currentX / 5) * 5, a = Math.round(e.sheet.currentY / 5) * 5;
			e.sheet.currentX = i, e.sheet.currentY = a, e.sheet.zIndex = i + a + 1e3, t.type !== "storage" && (e.store = null), n.push(t);
		}
		t.gear = n;
	}
	activateListeners(e) {
		if (super.activateListeners(e), this.options.editable && (e.find(".item-equip").click((e) => {
			let t = $(e.currentTarget).parents(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.equipped = !n.system.equipped, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".item-create").click((e) => {
			let t = [
				"item",
				"weapon",
				"spell",
				"armor",
				"condition",
				"storage"
			], n = "";
			for (let e of t) n += `<option value='${e}'>${e}</option>`;
			new Dialog({
				title: "Select Stat",
				content: `<h2> Item Type </h2> <select style='margin-bottom:10px;'name='type' id='type'> ${n}</select> <br/>`,
				buttons: {
					roll: {
						icon: "<i class=\"fas fa-check\"></i>",
						label: "Create",
						callback: (t) => this._onItemCreate(e, t.find("[id=\"type\"]")[0].value)
					},
					cancel: {
						icon: "<i class=\"fas fa-times\"></i>",
						label: "Cancel",
						callback: () => {}
					}
				},
				default: "roll",
				close: () => {}
			}).render(!0);
		}), e.find(".item-edit").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.getEmbeddedDocument("Item", t.data("itemId")).sheet.render(!0);
		}), e.find(".item-delete").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.deleteEmbeddedDocuments("Item", [t.data("itemId")]), t.slideUp(200, () => this.render(!1));
		}), e.find(".item-rotate").click((e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.sheet.rotation === -90 ? n.system.sheet.rotation = 0 : n.system.sheet.rotation = -90, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".stat-roll").click((e) => {
			let t = $(e.currentTarget).data("key"), n = this.actor.system.stats[t];
			this.actor.rollStat(n);
		}), e.find(".item-roll").click((e) => {
			let t = e.currentTarget.closest(".item");
			this.actor.rollItem(t.dataset.itemId, { event: e });
		}), e.on("change", ".item-input", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = $(e.currentTarget);
			n[r[0].name] = r[0].value, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".pip-button", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.pips.value;
			event.button === 0 ? r < n.system.pips.max && (n.system.pips.value = Number(r) + 1) : event.button === 2 && r > 0 && (n.system.pips.value = Number(r) - 1), this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".damage-swap", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.weapon.dmg1, i = n.system.weapon.dmg2;
			n.system.weapon.dmg1 = i, n.system.weapon.dmg2 = r, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), this.actor.isOwner)) {
			let t = (e) => this._onDragItemStart(e);
			e.find("li.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			}), e.find("div.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			});
		}
	}
	_onItemCreate(e, t) {
		e.preventDefault();
		let n = e.currentTarget, r = foundry.utils.duplicate(n.dataset), i = {
			name: `New ${t.capitalize()}`,
			type: t,
			data: r
		};
		return i.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [i]);
	}
	_onSkillCreate(e) {
		e.preventDefault();
		let t = e.currentTarget, n = {
			name: "New Skill",
			type: t.dataset.type,
			data: foundry.utils.duplicate(t.dataset)
		};
		return n.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [n]);
	}
	_onRoll(e) {
		e.preventDefault();
		let t = e.currentTarget.dataset;
		if (t.roll) {
			let e = new Roll(t.roll, this.actor.system), n = t.label ? `Rolling ${t.label} to score under ${t.target}` : "";
			e.roll().toMessage({
				speaker: ChatMessage.getSpeaker({ actor: this.actor }),
				flavor: n
			});
		}
	}
	async _updateObject(e, t) {
		let n = this.object, r = foundry.utils.expandObject(t);
		await n.update(r, { diff: !1 });
	}
	_onDragItemStart(e) {
		let t = e.currentTarget.getAttribute("data-item-id");
		if (!t) return;
		let n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t)), r = $(e.currentTarget), i = r.outerWidth(), a = r.outerHeight(), o = e.pageX - r.offset().left - i / 2, s = e.pageY - r.offset().top - a / 2;
		$(`#${t}`), n.system.stored = "";
		let c = n;
		e.dataTransfer.setData("text/plain", JSON.stringify({
			type: "Item",
			sheetTab: this.actor.flags._sheetTab,
			actorId: this.actor.id,
			itemId: t,
			fromToken: this.actor.isToken,
			offset: {
				x: o,
				y: s
			},
			data: c,
			root: e.currentTarget.getAttribute("root")
		}));
	}
	_onDragOver(e) {}
	async _onDropItem(e, t) {
		if (!this.actor.isOwner) return !1;
		let n = await Item.fromDropData(t), r = foundry.utils.duplicate(n), i = this.actor, a = $(e.target);
		a.attr("id") !== "drag-area" && (a = a.parents("#drag-area"));
		let o = 0, s = 0;
		if (a.length) {
			let t = a.outerWidth(), n = a.outerHeight();
			o = e.pageX - a.offset().left - t / 2, s = e.pageY - a.offset().top - n / 2;
		}
		if ((t.actorId === i.id || i.isToken && t.tokenId === i.token.id) && !e.ctrlKey) {
			let e = foundry.utils.duplicate(i.getEmbeddedDocument("Item", t.itemId));
			e.system.sheet = {
				currentX: o - t.offset.x,
				currentY: s - t.offset.y,
				initialX: o - t.offset.x,
				initialY: s - t.offset.y,
				xOffset: o - t.offset.x,
				yOffset: s - t.offset.y
			}, i.updateEmbeddedDocuments("Item", [e]);
			return;
		}
		return t.actorId && !e.ctrlKey && !t.fromToken && !this.actor.isToken && game.actors.get(t.actorId).deleteEmbeddedDocuments("Item", [t.itemId]), t.offset ||= {
			x: 0,
			y: 0
		}, r.system.sheet = {
			currentX: o - t.offset.x,
			currentY: s - t.offset.y,
			initialX: o - t.offset.x,
			initialY: s - t.offset.y,
			xOffset: o - t.offset.x,
			yOffset: s - t.offset.y
		}, this._onDropItemCreate(r);
	}
}, F = foundry.appv1.sheets.ActorSheet, I = class extends F {
	static get defaultOptions() {
		return foundry.utils.mergeObject(F.defaultOptions, {
			classes: [
				"mausritter",
				"sheet",
				"actor",
				"hireling"
			],
			template: "systems/mausritter/templates/actor/hireling-sheet.html",
			width: 680,
			height: 620,
			tabs: [{
				navSelector: ".sheet-tabs",
				contentSelector: ".sheet-body",
				initial: "character"
			}]
		});
	}
	getData() {
		let e = super.getData();
		return e.dtypes = [
			"String",
			"Number",
			"Boolean"
		], this.actor.type === "hireling" && this._prepareCharacterItems(e), e.data.system.settings ?? (e.data.system.settings = {}), e.data;
	}
	_prepareCharacterItems(e) {
		let t = e.actor, n = [];
		for (let t of e.items) {
			let e = t.system;
			t.img = t.img || DEFAULT_TOKEN, e.pips ??= {
				value: 0,
				max: 0,
				html: ""
			};
			let r = "";
			for (let t = 0; t < e.pips.max; t++) t < e.pips.value ? r += "<i class=\"fas fa-circle\"></i>" : r += "<i class=\"far fa-circle\"></i>";
			e.pips.html = r, t.type === "item" ? (e.isWeapon = !1, e.isCondition = !1) : t.type === "weapon" && (e.isWeapon = !0, e.isCondition = !1, e.weapon.dmg2 === "" ? e.weapon.canSwap = !1 : e.weapon.canSwap = !0), e.size === void 0 && (e.size = {
				width: 1,
				height: 1,
				x: "9em",
				y: "9em"
			}), e.sheet.rotation === void 0 && (e.sheet.rotation = 0), e.size.aspect = e.sheet.rotation === -90 ? e.size.width > e.size.height ? e.size.width / e.size.height : e.size.height / e.size.width : 1, e.sheet.curHeight = e.sheet.rotation === -90 ? e.size.width : e.size.height, e.sheet.curWidth = e.sheet.rotation === -90 ? e.size.height : e.size.width, e.size.x = `${e.sheet.curWidth * 8 + e.sheet.curWidth}em`, e.size.y = `${e.sheet.curHeight * 8 + e.sheet.curHeight}em`;
			let i = Math.round(e.sheet.currentX / 5) * 5, a = Math.round(e.sheet.currentY / 5) * 5;
			e.sheet.currentX = i, e.sheet.currentY = a, e.sheet.zIndex = i + a + 1e3, t.type !== "storage" && (e.store = null), n.push(t);
		}
		t.gear = n;
	}
	activateListeners(e) {
		if (super.activateListeners(e), this.options.editable && (e.find(".item-equip").click((e) => {
			let t = $(e.currentTarget).parents(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.equipped = !n.system.equipped, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".item-create").click((e) => {
			let t = [
				"item",
				"weapon",
				"spell",
				"armor",
				"condition",
				"storage"
			], n = "";
			for (let e of t) n += `<option value='${e}'>${e}</option>`;
			new Dialog({
				title: "Select Stat",
				content: `<h2> Item Type </h2> <select style='margin-bottom:10px;'name='type' id='type'> ${n}</select> <br/>`,
				buttons: {
					roll: {
						icon: "<i class=\"fas fa-check\"></i>",
						label: "Create",
						callback: (t) => this._onItemCreate(e, t.find("[id=\"type\"]")[0].value)
					},
					cancel: {
						icon: "<i class=\"fas fa-times\"></i>",
						label: "Cancel",
						callback: () => {}
					}
				},
				default: "roll",
				close: () => {}
			}).render(!0);
		}), e.find(".item-edit").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.getEmbeddedDocument("Item", t.data("itemId")).sheet.render(!0);
		}), e.find(".item-delete").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.deleteEmbeddedDocuments("Item", [t.data("itemId")]), t.slideUp(200, () => this.render(!1));
		}), e.find(".item-rotate").click((e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.sheet.rotation === -90 ? n.system.sheet.rotation = 0 : n.system.sheet.rotation = -90, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".stat-roll").click((e) => {
			let t = $(e.currentTarget).data("key"), n = this.actor.system.stats[t];
			this.actor.rollStat(n);
		}), e.find(".item-roll").click((e) => {
			let t = e.currentTarget.closest(".item");
			this.actor.rollItem(t.dataset.itemId, { event: e });
		}), e.on("change", ".item-input", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = $(e.currentTarget);
			n[r[0].name] = r[0].value, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".pip-button", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.pips.value;
			event.button === 0 ? r < n.system.pips.max && (n.system.pips.value = Number(r) + 1) : event.button === 2 && r > 0 && (n.system.pips.value = Number(r) - 1), this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".damage-swap", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.weapon.dmg1, i = n.system.weapon.dmg2;
			n.system.weapon.dmg1 = i, n.system.weapon.dmg2 = r, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), this.actor.isOwner)) {
			let t = (e) => this._onDragItemStart(e);
			e.find("li.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			}), e.find("div.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			});
		}
	}
	_onItemCreate(e, t) {
		e.preventDefault();
		let n = e.currentTarget, r = foundry.utils.duplicate(n.dataset), i = {
			name: `New ${t.capitalize()}`,
			type: t,
			data: r
		};
		return i.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [i]);
	}
	_onSkillCreate(e) {
		e.preventDefault();
		let t = e.currentTarget, n = {
			name: "New Skill",
			type: t.dataset.type,
			data: foundry.utils.duplicate(t.dataset)
		};
		return n.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [n]);
	}
	_onRoll(e) {
		e.preventDefault();
		let t = e.currentTarget.dataset;
		if (t.roll) {
			let e = new Roll(t.roll, this.actor.system), n = t.label ? `Rolling ${t.label} to score under ${t.target}` : "";
			e.roll().toMessage({
				speaker: ChatMessage.getSpeaker({ actor: this.actor }),
				flavor: n
			});
		}
	}
	async _updateObject(e, t) {
		let n = this.object, r = foundry.utils.expandObject(t);
		await n.update(r, { diff: !1 });
	}
	_onDragItemStart(e) {
		let t = e.currentTarget.getAttribute("data-item-id");
		if (!t) return;
		let n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t)), r = $(e.currentTarget), i = r.outerWidth(), a = r.outerHeight(), o = e.pageX - r.offset().left - i / 2, s = e.pageY - r.offset().top - a / 2;
		$(`#${t}`), n.system.stored = "";
		let c = n;
		e.dataTransfer.setData("text/plain", JSON.stringify({
			type: "Item",
			sheetTab: this.actor.flags._sheetTab,
			actorId: this.actor.id,
			itemId: t,
			fromToken: this.actor.isToken,
			offset: {
				x: o,
				y: s
			},
			data: c,
			root: e.currentTarget.getAttribute("root")
		}));
	}
	_onDragOver(e) {}
	async _onDropItem(e, t) {
		if (!this.actor.isOwner) return !1;
		let n = await Item.fromDropData(t), r = foundry.utils.duplicate(n), i = this.actor, a = $(e.target);
		a.attr("id") !== "drag-area" && (a = a.parents("#drag-area"));
		let o = 0, s = 0;
		if (a.length) {
			let t = a.outerWidth(), n = a.outerHeight();
			o = e.pageX - a.offset().left - t / 2, s = e.pageY - a.offset().top - n / 2;
		}
		if ((t.actorId === i.id || i.isToken && t.tokenId === i.token.id) && !e.ctrlKey) {
			let e = foundry.utils.duplicate(i.getEmbeddedDocument("Item", t.itemId));
			e.system.sheet = {
				currentX: o - t.offset.x,
				currentY: s - t.offset.y,
				initialX: o - t.offset.x,
				initialY: s - t.offset.y,
				xOffset: o - t.offset.x,
				yOffset: s - t.offset.y
			}, i.updateEmbeddedDocuments("Item", [e]);
			return;
		}
		return t.actorId && !e.ctrlKey && !t.fromToken && !this.actor.isToken && game.actors.get(t.actorId).deleteEmbeddedDocuments("Item", [t.itemId]), t.offset ||= {
			x: 0,
			y: 0
		}, r.system.sheet = {
			currentX: o - t.offset.x,
			currentY: s - t.offset.y,
			initialX: o - t.offset.x,
			initialY: s - t.offset.y,
			xOffset: o - t.offset.x,
			yOffset: s - t.offset.y
		}, this._onDropItemCreate(r);
	}
}, L = foundry.appv1.sheets.ActorSheet, R = class extends L {
	static get defaultOptions() {
		return foundry.utils.mergeObject(L.defaultOptions, {
			classes: [
				"mausritter",
				"sheet",
				"actor",
				"storage"
			],
			template: "systems/mausritter/templates/actor/storage-sheet.html",
			width: 475,
			height: 500,
			resizable: !1,
			tabs: [{
				navSelector: ".sheet-tabs",
				contentSelector: ".sheet-body",
				initial: "character"
			}]
		});
	}
	getData() {
		let e = super.getData();
		e.dtypes = [
			"String",
			"Number",
			"Boolean"
		], this.actor.type === "storage" && this._prepareCharacterItems(e), e.data.system.settings ?? (e.data.system.settings = {}), e.data.system.storeDiv = "", e.data.system.size.divWidth = e.data.system.size.width * 130 + 35, e.data.system.size.divHeight = e.data.system.size.height * 130 + 35;
		let t = 0;
		for (let n = 0; n < e.data.system.size.height; n++) for (let r = 0; r < e.data.system.size.width; r++) t++, e.data.system.storeDiv += `\
                <div class="item-slot-dashed" style="transform: translate3d(${r * 130 - (e.data.system.size.width - 1) * 65}px, ${n * 130 - (e.data.system.size.height - 1) * 65}px, 0px);">\
                    <div class="item-bag-text">\
                        ${t}\
                    </div>\
                </div>`;
		return this.position.width = e.data.system.size.width * 130 + 80, this.position.height = e.data.system.size.height * 130 + 230, e.data;
	}
	_prepareCharacterItems(e) {
		e.actor;
		let t = [];
		for (let n of e.items) {
			let e = n.system;
			n.img = n.img || DEFAULT_TOKEN, e.pips ??= {
				value: 0,
				max: 0,
				html: ""
			};
			let r = "";
			for (let t = 0; t < e.pips.max; t++) t < e.pips.value ? r += "<i class=\"fas fa-circle\"></i>" : r += "<i class=\"far fa-circle\"></i>";
			e.pips.html = r, n.type === "item" ? (e.isWeapon = !1, e.isCondition = !1) : n.type === "weapon" && (e.isWeapon = !0, e.isCondition = !1, e.weapon.dmg2 === "" ? e.weapon.canSwap = !1 : e.weapon.canSwap = !0), e.size === void 0 && (e.size = {
				width: 1,
				height: 1,
				x: "9em",
				y: "9em"
			}), e.sheet.rotation === void 0 && (e.sheet.rotation = 0), e.size.aspect = e.sheet.rotation === -90 ? e.size.width > e.size.height ? e.size.width / e.size.height : e.size.height / e.size.width : 1, e.sheet.curHeight = e.sheet.rotation === -90 ? e.size.width : e.size.height, e.sheet.curWidth = e.sheet.rotation === -90 ? e.size.height : e.size.width, e.size.x = `${e.sheet.curWidth * 8 + e.sheet.curWidth}em`, e.size.y = `${e.sheet.curHeight * 8 + e.sheet.curHeight}em`;
			let i = Math.round(e.sheet.currentX / 5) * 5, a = Math.round(e.sheet.currentY / 5) * 5;
			e.sheet.currentX = i, e.sheet.currentY = a, e.sheet.zIndex = i + a + 1e3, n.type !== "storage" && (e.store = null), t.push(n);
		}
		e.actor.gear = t, console.log(t);
	}
	activateListeners(e) {
		if (super.activateListeners(e), this.options.editable && (e.find(".item-equip").click((e) => {
			let t = $(e.currentTarget).parents(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.equipped = !n.system.equipped, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".item-create").click((e) => {
			let t = [
				"item",
				"weapon",
				"spell",
				"armor",
				"condition",
				"storage"
			], n = "";
			for (let e of t) n += `<option value='${e}'>${e}</option>`;
			new Dialog({
				title: "Select Stat",
				content: `<h2> Item Type </h2> <select style='margin-bottom:10px;'name='type' id='type'> ${n}</select> <br/>`,
				buttons: {
					roll: {
						icon: "<i class=\"fas fa-check\"></i>",
						label: "Create",
						callback: (t) => this._onItemCreate(e, t.find("[id=\"type\"]")[0].value)
					},
					cancel: {
						icon: "<i class=\"fas fa-times\"></i>",
						label: "Cancel",
						callback: () => {}
					}
				},
				default: "roll",
				close: () => {}
			}).render(!0);
		}), e.find(".item-edit").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.getEmbeddedDocument("Item", t.data("itemId")).sheet.render(!0);
		}), e.find(".item-delete").click((e) => {
			let t = $(e.currentTarget).parents(".item");
			this.actor.deleteEmbeddedDocuments("Item", [t.data("itemId")]), t.slideUp(200, () => this.render(!1));
		}), e.find(".item-rotate").click((e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId));
			n.system.sheet.rotation === -90 ? n.system.sheet.rotation = 0 : n.system.sheet.rotation = -90, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.find(".stat-roll").click((e) => {
			let t = $(e.currentTarget).data("key"), n = this.actor.system.stats[t];
			this.actor.rollStat(n);
		}), e.find(".item-roll").click((e) => {
			let t = e.currentTarget.closest(".item");
			this.actor.rollItem(t.dataset.itemId, { event: e });
		}), e.on("change", ".item-input", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = $(e.currentTarget);
			n[r[0].name] = r[0].value, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".pip-button", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.pips.value;
			event.button === 0 ? r < n.system.pips.max && (n.system.pips.value = Number(r) + 1) : event.button === 2 && r > 0 && (n.system.pips.value = Number(r) - 1), this.actor.updateEmbeddedDocuments("Item", [n]);
		}), e.on("mousedown", ".damage-swap", (e) => {
			let t = e.currentTarget.closest(".item"), n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t.dataset.itemId)), r = n.system.weapon.dmg1, i = n.system.weapon.dmg2;
			n.system.weapon.dmg1 = i, n.system.weapon.dmg2 = r, this.actor.updateEmbeddedDocuments("Item", [n]);
		}), this.actor.isOwner)) {
			let t = (e) => this._onDragItemStart(e);
			e.find("li.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			}), e.find("div.dropitem").each((e, n) => {
				n.classList.contains("inventory-header") || (n.setAttribute("draggable", !0), n.addEventListener("dragstart", t, !1));
			});
		}
	}
	_onItemCreate(e, t) {
		e.preventDefault();
		let n = e.currentTarget, r = foundry.utils.duplicate(n.dataset), i = {
			name: `New ${t.capitalize()}`,
			type: t,
			data: r
		};
		return i.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [i]);
	}
	_onSkillCreate(e) {
		e.preventDefault();
		let t = e.currentTarget, n = {
			name: "New Skill",
			type: t.dataset.type,
			data: foundry.utils.duplicate(t.dataset)
		};
		return n.data.type = void 0, this.actor.createEmbeddedDocuments("Item", [n]);
	}
	_onRoll(e) {
		e.preventDefault();
		let t = e.currentTarget.dataset;
		if (t.roll) {
			let e = new Roll(t.roll, this.actor.system), n = t.label ? `Rolling ${t.label} to score under ${t.target}` : "";
			e.roll().toMessage({
				speaker: ChatMessage.getSpeaker({ actor: this.actor }),
				flavor: n
			});
		}
	}
	async _updateObject(e, t) {
		let n = this.object, r = foundry.utils.expandObject(t);
		await n.update(r, { diff: !1 });
	}
	_onDragItemStart(e) {
		let t = e.currentTarget.getAttribute("data-item-id");
		if (!t) return;
		let n = foundry.utils.duplicate(this.actor.getEmbeddedDocument("Item", t)), r = $(e.currentTarget), i = r.outerWidth(), a = r.outerHeight(), o = e.pageX - r.offset().left - i / 2, s = e.pageY - r.offset().top - a / 2;
		$(`#${t}`), n.system.stored = "";
		let c = n;
		e.dataTransfer.setData("text/plain", JSON.stringify({
			type: "Item",
			sheetTab: this.actor.flags._sheetTab,
			actorId: this.actor.id,
			itemId: t,
			fromToken: this.actor.isToken,
			offset: {
				x: o,
				y: s
			},
			data: c,
			root: e.currentTarget.getAttribute("root")
		}));
	}
	_onDragOver(e) {}
	async _onDropItem(e, t) {
		if (!this.actor.isOwner) return !1;
		let n = await Item.fromDropData(t), r = foundry.utils.duplicate(n), i = this.actor, a = $(e.target);
		a.attr("id") !== "drag-area" && (a = a.parents("#drag-area"));
		let o = 0, s = 0;
		if (a.length) {
			let t = a.outerWidth(), n = a.outerHeight();
			o = e.pageX - a.offset().left - t / 2, s = e.pageY - a.offset().top - n / 2;
		}
		if ((t.actorId === i.id || i.isToken && t.tokenId === i.token.id) && !e.ctrlKey) {
			let e = foundry.utils.duplicate(i.getEmbeddedDocument("Item", t.itemId));
			e.system.sheet = {
				currentX: o - t.offset.x,
				currentY: s - t.offset.y,
				initialX: o - t.offset.x,
				initialY: s - t.offset.y,
				xOffset: o - t.offset.x,
				yOffset: s - t.offset.y
			}, i.updateEmbeddedDocuments("Item", [e]);
			return;
		}
		return t.actorId && !e.ctrlKey && !t.fromToken && !this.actor.isToken && game.actors.get(t.actorId).deleteEmbeddedDocuments("Item", [t.itemId]), t.offset ||= {
			x: 0,
			y: 0
		}, r.system.sheet = {
			currentX: o - t.offset.x,
			currentY: s - t.offset.y,
			initialX: o - t.offset.x,
			initialY: s - t.offset.y,
			xOffset: o - t.offset.x,
			yOffset: s - t.offset.y
		}, this._onDropItemCreate(r);
	}
}, z = class e extends Item {
	prepareData() {
		super.prepareData(), this.actor && this.actor.system, this.system;
	}
	static chatListeners(t) {
		t.on("click", ".use-skill", e._onChatUseSkill.bind(e));
	}
	static async _onChatUseSkill(t) {
		let n = t.currentTarget.closest(".mausritter"), r = e._getChatCardActor(n);
		if (!r) return;
		let i = t.currentTarget.children[0].dataset.itemId;
		r.rollSkill(i);
	}
}, B = foundry.appv1.sheets.ItemSheet, V = class extends B {
	static get defaultOptions() {
		return foundry.utils.mergeObject(B.defaultOptions, {
			classes: [
				"mausritter",
				"sheet",
				"item"
			],
			width: 520,
			height: 480,
			tabs: [{
				navSelector: ".sheet-tabs",
				contentSelector: ".sheet-body",
				initial: "description"
			}]
		});
	}
	get template() {
		return `systems/mausritter/templates/item/item-${this.item.type}-sheet.html`;
	}
	getData() {
		return super.getData().data;
	}
	setPosition(e = {}) {
		let t = super.setPosition(e), n = this.element.find(".sheet-body"), r = t.height - 192;
		return n.css("height", r), t;
	}
	activateListeners(e) {
		super.activateListeners(e), super.getData(), this.options.editable;
	}
}, H = foundry.documents.collections.Actors, U = foundry.documents.collections.Items;
Hooks.once("init", async () => {
	game.mausritter = {
		MausritterActor: n,
		MausritterItem: z,
		rollItemMacro: G,
		rollStatMacro: K,
		autoCreateCharacter: C
	}, CONFIG.Combat.initiative = {
		formula: "1d100",
		decimals: 2
	}, CONFIG.Actor.documentClass = n, CONFIG.Item.documentClass = z, CONFIG.MAUSRITTER = {}, CONFIG.MAUSRITTER.tables = {
		tables: "Tables",
		birthsign: "Birthsign",
		physicalDetail: "Physical detail",
		coatPattern: "Mousy Coat Pattern",
		coatColor: "Mousy Coat Color",
		firstName: "Mousy Names - Birthname",
		lastName: "Mousy Names - Matriname",
		npcAppearance: "Non-player mice - Appearance",
		npcBirthsign: "Non-player mice - Birthsign and Disposition",
		npcQuirk: "Non-player mice - Quirk",
		npcSocial: "Non-player mice - Social position and Payment for service",
		npcWants: "Non-player mice - Wants",
		npcRelationship: "Non-player mice - Relationship"
	}, H.unregisterSheet("core", foundry.appv1.sheets.ActorSheet), H.registerSheet("mausritter", i, {
		types: ["character"],
		makeDefault: !0
	}), H.registerSheet("mausritter", I, {
		types: ["hireling"],
		makeDefault: !1
	}), H.registerSheet("mausritter", P, {
		types: ["creature"],
		makeDefault: !1
	}), H.registerSheet("mausritter", R, {
		types: ["storage"],
		makeDefault: !1
	}), U.unregisterSheet("core", foundry.appv1.sheets.ItemSheet), U.registerSheet("mausritter", V, { makeDefault: !0 }), Handlebars.registerHelper("toLowerCase", (e) => e.toLowerCase()), CONFIG.Combat.initiative = {
		formula: "-1d20+@stats.dexterity.value",
		decimals: 2
	};
}), Hooks.on("preCreateActor", (e, t, n, r) => {
	let i = CONST.TOKEN_DISPOSITIONS.NEUTRAL;
	t.type === "creature" && (i = CONST.TOKEN_DISPOSITIONS.HOSTILE), foundry.utils.mergeObject(t, {
		"token.bar1": { attribute: "health" },
		"token.bar2": { stat: "strength" },
		"token.displayName": CONST.TOKEN_DISPLAY_MODES.OWNER_HOVER,
		"token.displayBars": CONST.TOKEN_DISPLAY_MODES.OWNER_HOVER,
		"token.disposition": i,
		"token.name": t.name
	}), t.type === "character" && (t.token.vision = !0, t.token.actorLink = !0);
}), Hooks.once("ready", async () => {
	Hooks.on("hotbarDrop", (e, t, n) => {
		if (t.type === "Item") return W(t, n), !1;
	});
});
async function W(e, t) {
	let n = {
		type: "script",
		scope: "actor"
	}, r = await Item.implementation.fromDropData(e);
	if (!r) return ui.notifications.warn("You can only create macro buttons for owned Items"), null;
	foundry.utils.foundry.utils.mergeObject(n, {
		name: r.name,
		img: r.img,
		command: `game.mausritter.rollItemMacro("${r.name}")`,
		flags: { "mausritter.itemMacro": !0 }
	});
	let i = game.macros.find((e) => e.name === n.name && e.command === n.command && e.isAuthor) || await Macro.create(n);
	game.user.assignHotbarMacro(i, t);
}
function G(e) {
	let t = ChatMessage.getSpeaker(), n;
	t.token && (n = game.actors.tokens[t.token]), n ||= game.actors.get(t.actor);
	let r = n ? n.items.find((t) => t.name === e) : null;
	return r ? n.rollItem(r.id) : ui.notifications.warn(`Your controlled Actor does not have an item named ${e}`);
}
function K() {
	let e = canvas.tokens.controlled, t = ChatMessage.getSpeaker();
	e.length === 0 && (e = game.actors.tokens[t.token]);
	let n;
	t.token && (n = game.actors.tokens[t.token]), n ||= game.actors.get(t.actor);
	let r = n ? Object.entries(n.system.stats) : null;
	return n.rollStatSelect(r);
}
//#endregion

//# sourceMappingURL=mausritter.js.map